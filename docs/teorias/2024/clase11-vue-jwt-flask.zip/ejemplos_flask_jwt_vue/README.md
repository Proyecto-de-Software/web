# Ejemplo Flask <-jwt-> Vue (en cookies)

## En **docker-compose.yml** estan los servicios

- db: servidor de base de datos postgres.
- pgadmin: aplicación pgAdmin 4.

Se incia con: docker-compose up
## Carpeta **admin**

Aplicación backend en flask (con Flask-JWT-Extended):

- asdf exec poetry install
- asdf exec poetry run flask resetdb
- asdf exec poetry run flask seeds
- asdf exec poetry run flask run 

Antes debemos crear la base de datos vacía **proyecto**.
El servidor queda levantado en el puerto 5000.

## Carpeta **frontend**

Aplicación frontend de vue (router+vuex): 

- npm install
- npm run dev

Usuarios:

fede@mail.com y agus@mail.com con pass 1234