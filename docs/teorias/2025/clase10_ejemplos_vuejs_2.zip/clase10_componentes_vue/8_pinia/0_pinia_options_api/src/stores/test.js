import { defineStore } from 'pinia'

export const useCounterPiniaStore = defineStore('counterStore', {
  state: () => {
      return {
        count: 0
      }
  },
  actions: {
    increment() {
      this.count++
    },
    randomizeCounter() {
      this.count = Math.round(100 * Math.random())
    },
  },
})
