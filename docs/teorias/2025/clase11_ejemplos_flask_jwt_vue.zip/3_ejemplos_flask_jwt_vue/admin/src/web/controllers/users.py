from flask import Blueprint
from flask import render_template

from src.core import auth
from src.web.helpers.auth import login_required

from flask import request, jsonify
from flask_jwt_extended import jwt_required

user_blueprint = Blueprint("users", __name__, url_prefix="/users")


@user_blueprint.route("/")
@login_required
def index():
    users = auth.list_users()
    return render_template("users/index.html", users=users)



@user_blueprint.get('/list')
@jwt_required( )
def list_users():
    users = auth.list_users()
    response = jsonify(users)
    return response, 200