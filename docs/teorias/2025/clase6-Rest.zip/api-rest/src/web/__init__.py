from flask import Flask, render_template

from src.core.personas import personas
from src.core.db import db, init_db, configure_db
from src.web.controllers.issues import issue_blueprint
from src.web.controllers.api_v1 import api_v1_blueprint
from src.web.helpers import handler
from flask_session import Session
from flask import session
import os
from dotenv import load_dotenv
import click

load_dotenv()


def create_app():

    app = Flask(__name__)

    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("SQLALCHEMY_DATABASE_URI")
    app.config["SQLALCHEMY_ECHO"] = os.getenv("SQLALCHEMY_ECHO")

    #

    init_db(app)
    with app.app_context():
        # db.drop_all()
        db.create_all()
    # db.configure_db(app)

    app.config["SESSION_TYPE"] = "filesystem"

    Session(app)

    @app.route("/")
    @app.route("/<string:name>")
    def hello_world(name=None):
        print()
        if session.get("username"):
            print("Usuario anterior:", session.get("username"))
        else:
            print("No hay usuario en sesión")
        if name:
            session["username"] = name
            print("Usuario nuevo", session.get("username"))
        else:
            print("No hay usuario en sesión")
        return render_template("index.html", name=name)

    # @app.route("/")
    # def home():
    #     return "Home Page!"

    @app.route("/about")
    def about():
        return "About Page"

    @app.teardown_appcontext
    def shutdown_session(exception=None):
        db.session.remove()

    app.register_blueprint(issue_blueprint)
    app.register_blueprint(api_v1_blueprint)

    app.register_error_handler(404, handler.not_found_error)
    app.register_error_handler(500, handler.generic_error)

    # @app.route("/issues", methods=["GET", "POST"])
    # def issues_index():
    #     if issues is None:
    #         return "No issues found", 404
    #     elif request.method == "POST":
    #         # Handle form submission
    #         issue = {
    #             "id": request.form.get("id"),
    #             "user": request.form.get("user"),
    #             "title": request.form.get("title"),
    #             "description": request.form.get("description"),
    #             "status": request.form.get("status"),
    #         }
    #         issues.append(issue)
    #         return render_template("issues/index.html", issues=issues)
    #     elif request.method == "GET":
    #         return render_template("issues/index.html", issues=issues)
    #     else:
    #         return "Method not allowed", 405

    # @app.route("/issues/add", methods=["POST"])
    # def issues_add():
    #     issue = {
    #         "id": request.form.get("id"),
    #         "user": request.form.get("user"),
    #         "title": request.form.get("title"),
    #         "description": request.form.get("description"),
    #         "status": request.form.get("status"),
    #     }
    #     issues.append(issue)
    #     return render_template("issues/index.html", issues=issues)

    @app.route("/personas")
    def personas_index():
        return render_template("personas/index.html", personas=personas)
    

    @app.cli.command('init-db')
    @click.option('--drop-tables', is_flag=True, help='Drop existing tables before creating new ones.')
    def init_db_command(drop_tables):
        """Initializes the database tables."""
        if drop_tables:
            db.drop_all()
            click.echo('Dropped all tables.')
        db.create_all()
        click.echo('Initialized the database!')

    return app
