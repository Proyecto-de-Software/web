
Modifiquemos app.products:
 Agregando: app.products.push("Manteca")
 Eliminando: app.products.pop()