<script>
    import { mapState } from 'pinia'
    import { useCounterPiniaStore } from '@/stores/test'

    export default {
        computed: {
            ...mapState(useCounterPiniaStore, ['count','randomizeCounter', 'increment']),
        },
    }
</script>

<template>
    <pre>Counter: {{ count }}</pre>
    <button @click="increment()">+</button>
    <button @click="randomizeCounter()">Randomize</button>
</template>
