from flask import Flask
from flask import render_template
from flask_session import Session

from flask_cors import CORS

from src.core import board
from src.core import database
from src.core import seeds
from src.web.config import config
from src.web.helpers import handler
from src.web.helpers import auth
from src.web.controllers.issue import issue_blueprint
from src.web.controllers.users import user_blueprint
from src.web.controllers.auth import auth_blueprint

from flask_jwt_extended import JWTManager

import logging

logging.basicConfig()
logging.getLogger("sqlalchemy.engine").setLevel(logging.INFO)


def create_app(env="development", static_folder="static"):
    app = Flask(__name__, static_folder=static_folder)

    # Import config
    app.config.from_object(config[env])

    # CORS
    CORS(app, supports_credentials=True)

    # Server Side session
    Session(app)

    # Configure db
    db = database.init_app(app)

    #JWT
    jwt = JWTManager(app)

    # Define home
    @app.route("/")
    def home():
        return render_template("home.html")

    # Load blueprints
    app.register_blueprint(issue_blueprint)
    app.register_blueprint(user_blueprint)
    app.register_blueprint(auth_blueprint)

    # Error handlers
    app.register_error_handler(404, handler.not_found_error)
    app.register_error_handler(500, handler.generic_error)
    app.register_error_handler(401, handler.unauthorized)

    # Add to jinja
    app.jinja_env.globals.update(is_authenticated=auth.is_authenticated)

    # Commands
    @app.cli.command(name="resetdb")
    def resetdb():
        """Elimino y creo la base de datos."""
        database.init_db()

    @app.cli.command(name="seeds")
    def seedsdb():
        seeds.run()
   
    return app
