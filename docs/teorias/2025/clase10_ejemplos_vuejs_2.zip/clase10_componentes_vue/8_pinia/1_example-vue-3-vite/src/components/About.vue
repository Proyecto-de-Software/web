<template>
    <div>
      <h1>About </h1>
      <p> Usuario logueado: {{ userStore.name }} <span v-if="userStore.isAdmin">( Administrador!!! )</span></p>
    </div>
</template>
  
<script>
    // Usando Options API => https://vuejs.org/api/options-state.html
    import { mapStores } from 'pinia'
    import { useUserStore } from '../stores/user'

    export default {
        computed: {
            // note we are not passing an array, just one store after the other
            // each store will be accessible as its id + 'Store'
            ...mapStores(useUserStore)
        },
    }
</script>
