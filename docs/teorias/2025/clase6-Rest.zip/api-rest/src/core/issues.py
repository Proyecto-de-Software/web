from src.core.db import db


class Issue(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    # status = db.Column(db.String(20), nullable=False)
    type_id = db.Column(db.Integer, db.ForeignKey("issue_type.id"))
    type = db.relationship("IssueType", backref="issues")
    status_id = db.Column(db.Integer, db.ForeignKey("issue_status.id"))
    # status = db.relationship("IssueStatus", backref="issues")

    # type = db.relationship("IssueType", backref="issues", lazy=True)
    updated_at = db.Column(
        db.DateTime, server_default=db.func.now(), onupdate=db.func.now()
    )
    created_at = db.Column(db.DateTime, server_default=db.func.now())

    def __repr__(self):
        return f"<Issue {self.id} - {self.type_id}>"


class IssueType(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=True)
    # issues = db.relationship("Issue", backref="type", lazy=True)

    def __repr__(self):
        return f"<IssueType {self.id} - {self.name}>"


class IssueStatus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=True)
    issues = db.relationship("Issue", backref="status", lazy=True)

    def __repr__(self):
        return f"<IssueStatus {self.id} - {self.name}>"


# conn = sqlite3.connect('proyecto_db.db')
# cur = conn.cursor()
# cur.execute('SELECT * FROM issues')
# issues = cur.fetchall()
# cur.close()
# conn.close()
# issues = []
# conn = psycopg2.connect(
#         host="localhost",
#         database="proyecto_db",
#         user="proyecto_db",
#         password="proyecto_db")

# cur = conn.cursor()

# cur.execute('select * from issues')
# issues = cur.fetchall()
# cur.close()
# conn.close()


# issues = [
#     {
#         "id": 1,
#         "user": "José",
#         "title": "Mi computadora no funciona.",
#         "description": "Mi departamente me compró una nueva computadora y necesito configurarla con todos mis emails y documentos de mi vieja computadora.",
#         "status": "new",
#     },
#     {
#         "id": 2,
#         "user": "María",
#         "title": "No puedo obtener mis emails.",
#         "description": "Estoy tratando de acceder a mi correo desde casa, pero no puedo obtenerlos. Estoy tratando con Outlook en mi casa pero en la oficina tengo Thunderbird.",
#         "status": "in_progress",
#     },
#     {
#         "id": 3,
#         "user": "Rubén",
#         "title": "No puedo imprimir",
#         "description": "Cada vez que trato de imprimir mi presentación el programa se cierra. Esto sólo me pasa con PowerPoint en Word puedo imprimir. Ya me aseguré que la impresora está prendida. Tengo una HP LaserJet 5.",
#         "status": "done",
#     },
# ]
