personas = [
    {"id": 1, "nombre": "José", "edad": 30, "email": "jose@example.com"},
    {"id": 2, "nombre": "María", "edad": 25, "email": "maria@example.com"},
    {"id": 3, "nombre": "Rubén", "edad": 28, "email": "ruben@example.com"},
]
