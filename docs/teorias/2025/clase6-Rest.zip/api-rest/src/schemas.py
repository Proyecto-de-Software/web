from marshmallow import fields
from src.core.db import db
from src.core.issues import Issue, IssueType, IssueStatus
from marshmallow_sqlalchemy import SQLAlchemyAutoSchema, auto_field


class IssueTypeSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = IssueType
        load_instance = True
        include_relationships = True
        sqla_session = db.session

    id = auto_field()
    name = auto_field()
    description = auto_field()
    issues = fields.Nested("IssueSchema", many=True, exclude=("type", "status"))


class IssueStatusSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = IssueStatus
        load_instance = True
        include_relationships = True
        sqla_session = db.session

    id = auto_field()
    name = auto_field()
    description = auto_field()
    issues = fields.Nested("IssueSchema", many=True, exclude=("type", "status"))


class IssueSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Issue
        load_instance = True
        include_relationships = True
        sqla_session = db.session

    id = auto_field()
    user = auto_field()
    title = auto_field()
    description = auto_field()
    type_id = auto_field()
    type = fields.Nested(IssueTypeSchema, exclude=("issues",))
    status_id = auto_field()
    status = fields.Nested(IssueStatusSchema, exclude=("issues",))
    updated_at = auto_field()
    created_at = auto_field()
