from flask import Blueprint, jsonify, request
from src.schemas import IssueSchema, IssueTypeSchema, IssueStatusSchema
from src.core.issues import Issue
from marshmallow import ValidationError
from sqlalchemy.orm import joinedload
from src.core.db import db

# Crea un Blueprint específico para la API
api_v1_blueprint = Blueprint("api_v1", __name__, url_prefix="/apiv1")

# Inicializa los esquemas
issue_schema = IssueSchema()
issues_schema = IssueSchema(many=True)
issue_type_schema = IssueTypeSchema()
issue_types_schema = IssueTypeSchema(many=True)
issue_status_schema = IssueStatusSchema()
issue_statuses_schema = IssueStatusSchema(many=True)


@api_v1_blueprint.route("/issues", methods=["GET", "POST"])
def issues_api():
    if request.method == "POST":
        try:
            new_issue = issue_schema.load(request.form)
            db.session.add(new_issue)
            db.session.commit()
            return jsonify(issue_schema.dump(new_issue)), 201
        except ValidationError as err:
            return jsonify(err.messages), 400

    elif request.method == "GET":
        issues = Issue.query.options(
            joinedload(Issue.type), joinedload(Issue.status)
        ).all()
        return jsonify(issues_schema.dump(issues))

@api_v1_blueprint.route("/issues/<int:issue_id>", methods=["GET"])
def get_issue(issue_id):
    issue = Issue.query.options(
        joinedload(Issue.type), joinedload(Issue.status)
    ).get_or_404(issue_id)
    return jsonify(issue_schema.dump(issue))



@api_v1_blueprint.route("/issues/<int:issue_id>", methods=["PUT"])
def update_issue(issue_id):
    try:
        # 1. Busca el Issue a actualizar.
        issue = Issue.query.get_or_404(issue_id)

        # 2. Deserializa y valida los datos recibidos.
        #    'partial=True' permite actualizar solo algunos campos, sin requerir todos.
        updated_issue_data = issue_schema.load(
            request.form, instance=issue, partial=True
        )

        # 3. La instancia 'issue' ya fue actualizada por Marshmallow,
        #    solo necesitas confirmar los cambios en la base de datos.
        db.session.commit()

        # 4. Devuelve el objeto actualizado serializado.
        return jsonify(issue_schema.dump(updated_issue_data)), 200

    except ValidationError as err:
        return jsonify(err.messages), 400


@api_v1_blueprint.route("/issues/<int:issue_id>", methods=["DELETE"])
def delete_issue(issue_id):
    # 1. Busca el Issue a eliminar.
    issue = Issue.query.get_or_404(issue_id)

    # 2. Elimina el objeto de la sesión.
    db.session.delete(issue)

    # 3. Confirma la eliminación en la base de datos.
    db.session.commit()

    # 4. Devuelve una respuesta vacía o un mensaje de éxito con un código 204.
    return "", 204
