from flask import Blueprint, render_template, request
from src.core.issues import Issue, IssueType, IssueStatus
from src.core.db import db
from sqlalchemy.orm import joinedload


issue_blueprint = Blueprint("issues", __name__, url_prefix="/issues")


@issue_blueprint.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        issue = {
            # "id": request.form.get("id"),
            "user": request.form.get("user"),
            "title": request.form.get("title"),
            "description": request.form.get("description"),
            # "status": request.form.get("status"),
            "status_id": request.form.get("status_id"),
            "type_id": request.form.get("type_id"),
        }
        print(request.form)
        # issues.append(issue)
        issue = Issue(**issue)
        db.session.add(issue)
        db.session.commit()

        issues = Issue.query.all()
        issue_types = IssueType.query.all()
        issue_statuses = IssueStatus.query.all()
        return render_template(
            "issues/index.html", issues=issues, issue_types=issue_types, issue_statuses=issue_statuses
        )
    elif request.method == "GET":
        issues = Issue.query.options(joinedload(Issue.type)).all()
        issue_types = IssueType.query.all()
        issue_statuses = IssueStatus.query.all()
        return render_template(
            "issues/index.html", issues=issues, issue_types=issue_types, issue_statuses=issue_statuses
        )
    else:
        return "Method not allowed", 405


@issue_blueprint.route("/type", methods=["GET", "POST"])
def type():
    if request.method == "POST":
        issue_type = {
            # "id": request.form.get("id"),
            "name": request.form.get("name"),
            "description": request.form.get("description"),
        }
        issue_type = IssueType(**issue_type)
        db.session.add(issue_type)
        db.session.commit()

        issue_types = IssueType.query.all()
        return render_template("issues/issue_type.html", issues=issue_types)
    elif request.method == "GET":
        issue_types = IssueType.query.all()
        return render_template("issues/issue_type.html", issues=issue_types)
    else:
        return "Method not allowed", 405


@issue_blueprint.route("/status", methods=["GET", "POST"])
def status():
    if request.method == "POST":
        issue_status = {
            # "id": request.form.get("id"),
            "name": request.form.get("name"),
            "description": request.form.get("description"),
        }
        issue_status = IssueStatus(**issue_status)
        db.session.add(issue_status)
        db.session.commit()

        issue_statuses = IssueStatus.query.all()
        return render_template("issues/issue_status.html", issues=issue_statuses)
    elif request.method == "GET":
        issue_statuses = IssueStatus.query.all()
        return render_template("issues/issue_status.html", issues=issue_statuses)
    else:
        return "Method not allowed", 405
